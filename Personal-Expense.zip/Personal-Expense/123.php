<?php
// admin_login.php
require_once "config.php";
session_start();
$err = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';
    if ($password === "password") {
        $_SESSION['is_admin'] = true;
        header("Location: admin_dashboard.php");
        exit();
    } else {
        $err = "Invalid admin password.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Admin Login</title>
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
  <div class="row justify-content-center">
    <div class="col-md-5">
      <div class="card shadow-sm">
        <div class="card-body">
          <h4 class="mb-3 text-center">Admin Login</h4>
          <?php if(!empty($err)): ?>
          <div class="alert alert-danger py-2"><?php echo htmlspecialchars($err); ?></div>
          <?php endif; ?>
          <form method="post" autocomplete="off">
            <div class="form-group">
              <label for="password">Password</label>
              <input type="password" name="password" id="password" class="form-control" required>
            </div>
            <button class="btn btn-primary btn-block mt-3" type="submit">Login</button>
          </form>
          <div class="mt-3 text-center">
            <a href="index.php">← Back to App</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script src="js/jquery.slim.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>
