<?php
date_default_timezone_set('Asia/Yangon');
include("session.php");

// Get user profile
$userQuery = mysqli_query($con, "SELECT * FROM admin");
$userData = mysqli_fetch_assoc($userQuery);

$lastname ="Admin";
$useremail = $userData['email'];
$profilePic = !empty($userData['profile_path']) ? 'uploads/' . $userData['profile_path'] : 'uploads/a.jpg';

// Handle delete request
if (isset($_GET['delete_id'])) {
    $deleteId = intval($_GET['delete_id']);
    mysqli_query($con, "DELETE FROM suggestions WHERE id = $deleteId");
    header("Location: view_suggestion.php");
    exit();
}

// Handle new comment submission
if (isset($_POST['submit_comment'])) {
    $comment = trim($_POST['comment']);
    if (!empty($comment)) {
        $stmt = mysqli_prepare($con, "INSERT INTO suggestions (user_id, comment) VALUES (?, ?)");
        mysqli_stmt_bind_param($stmt, 'is', $userid, $comment);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        header("Location: suggestion.php"); // Prevent resubmission
        exit();
    } else {
        $error = "Please write something before submitting.";
    }
}

// Fetch all comments (latest first)
$commentsResult = mysqli_query($con, "
    SELECT s.id, s.comment, s.created_at, u.firstname, u.lastname 
    FROM suggestions s
    JOIN users u ON s.user_id = u.user_id
    ORDER BY s.created_at DESC
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Expense Manager - Suggestion Box</title>
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <script src="js/feather.min.js"></script>
</head>
<body>
<div class="d-flex" id="wrapper">

    <!-- Sidebar -->
    <div class="border-right" id="sidebar-wrapper" style="background-color: #ce9cdfff">
        <div class="user text-center p-3">
            <img class="img img-fluid rounded-circle mb-2" src="<?php echo $profilePic; ?>" width="120">
            <h5><?php echo htmlspecialchars($lastname); ?></h5>
            <p><?php echo htmlspecialchars($useremail); ?></p>
        </div>
        <div class="sidebar-heading" style="color: #333";>Management</div>
          <div class="list-group list-group-flush">
        <a href="view_user.php"class="list-group-item list-group-item-action"><span data-feather="plus-square"></span>View Users</a>    
        <a href="view_expense.php" class="list-group-item list-group-item-action"><span data-feather="dollar-sign"></span> View Expenses</a>
        <a href="view_category.php" class="list-group-item list-group-item-action"><span data-feather="file-text"></span> View Category</a>
        <a href="view_suggestion.php" class="list-group-item list-group-item-action"><span data-feather="message-square"></span> Suggestion Box</a>  
      </div>
        <div class="sidebar-heading"style="color: #333">Settings </div>
        <div class="list-group list-group-flush">
            <a href="logout.php" class="list-group-item list-group-item-action"><span data-feather="power"></span> Logout</a>
        </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    <div id="page-content-wrapper">
        <nav class="navbar navbar-expand-lg navbar-light border-bottom" style="background-color: #ce9cdfff">
            <button class="toggler" type="button" id="menu-toggle" style="background-color: #ce9cdfff">
                <span data-feather="menu"></span>
            </button>
            <div class="col-md-12 text-center">
                <h3>Suggestion Box</h3>
            </div>
        </nav>

        <div class="container mt-4">
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <!-- Display Comments -->
            <h4>All Suggestions</h4>
            <?php if (mysqli_num_rows($commentsResult) > 0): ?>
                <?php while ($row = mysqli_fetch_assoc($commentsResult)): ?>
                    <div class="card mb-2" >
                        <div class="card-body d-flex justify-content-between align-items-start" >
                            <div style="border-radius:10px">
                                <p class="mb-1"><?php echo nl2br(htmlspecialchars($row['comment'])); ?></p>
                                <small class="text-muted">
                                    By <?php echo htmlspecialchars($row['firstname'] . " " . $row['lastname']); ?> 
                                    on <?php echo date("d M Y, H:i", strtotime($row['created_at'])); ?>
                                </small>
                            </div>
                            <a href="?delete_id=<?php echo $row['id']; ?>" 
                               class="btn btn-sm btn-danger"
                               onclick="return confirm('Are you sure you want to delete this suggestion?');">
                               Delete
                            </a>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>No suggestions yet.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<script src="js/jquery.slim.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script>
    feather.replace();
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
</script>
</body>
</html>
