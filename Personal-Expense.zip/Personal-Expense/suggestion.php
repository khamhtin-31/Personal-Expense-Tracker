<?php
date_default_timezone_set('Asia/Yangon');
include("session.php");

// Get user profile
$userQuery = mysqli_query($con, "SELECT firstname, lastname, email, profile_path FROM users WHERE user_id = '$userid'");
$userData = mysqli_fetch_assoc($userQuery);

$username = $userData['firstname'] . " " . $userData['lastname'];
$useremail = $userData['email'];
$profilePic = !empty($userData['profile_path']) ? 'uploads/' . $userData['profile_path'] : 'uploads/a.jpg';

// Handle new comment submission
// if (isset($_POST['submit_comment'])) {
//     $comment = trim($_POST['comment']);
//     if (!empty($comment)) {
//         $stmt = mysqli_prepare($con, "INSERT INTO suggestions (user_id, comment) VALUES (?, ?)");
//         mysqli_stmt_bind_param($stmt, 'is', $userid, $comment);
//         mysqli_stmt_execute($stmt);
//         mysqli_stmt_close($stmt);
//         header("Location: suggestion.php"); // Prevent form resubmission
//         exit();
//     } else {
//         $error = "Please write something before submitting.";
//     }
// }

if (isset($_POST['submit_comment'])) {
    $comment = trim($_POST['comment']);
    if (!empty($comment)) {
        $stmt = $con->prepare("CALL add_suggestion(?, ?)");
        $stmt->bind_param("is", $userid, $comment);
        $stmt->execute();
        $stmt->close();

        header("Location: suggestion.php"); // Prevent form resubmission
        exit();
    } else {
        $error = "Please write something before submitting.";
    }
}


// Fetch all comments (latest first)
$commentsResult = mysqli_query($con, "
    SELECT s.comment, s.created_at, u.firstname, u.lastname 
    FROM suggestions s
    JOIN users u ON s.user_id = u.user_id
    ORDER BY s.created_at DESC
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Expense Manager - Suggestion Box</title>
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <script src="js/feather.min.js"></script>
</head>
<body>
<div class="d-flex" id="wrapper">

    <!-- Sidebar -->
    <div class="border-right" id="sidebar-wrapper" style="background-color:#ce9cdfff">
        <div class="user">
            <img class="img img-fluid rounded-circle" src="<?php echo $profilePic; ?>" width="120">
            <h5><?php echo $username ?></h5>
            <p><?php echo $useremail ?></p>
        </div>
        <div class="sidebar-heading" style="color: #333">Management</div>
        <div class="list-group list-group-flush">
            <a href="index.php" class="list-group-item list-group-item-action"><span data-feather="home"></span> Dashboard</a>
            <a href="add_expense.php" class="list-group-item list-group-item-action"><span data-feather="plus-square"></span> Add Expenses</a>
            <a href="manage_expense.php" class="list-group-item list-group-item-action"><span data-feather="dollar-sign"></span> Manage Expenses</a>
            <a href="expensereport.php" class="list-group-item list-group-item-action"><span data-feather="file-text"></span> Expense Report</a>
            <a href="suggestion.php" class="list-group-item list-group-item-action sidebar-active"><span data-feather="message-square"></span> Suggestion Box</a>
        </div>
        <div class="sidebar-heading" style="color: #333">Settings </div>
        <div class="list-group list-group-flush">
            <a href="profile.php" class="list-group-item list-group-item-action"><span data-feather="user"></span> Profile</a>
            <a href="logout.php" class="list-group-item list-group-item-action"><span data-feather="power"></span> Logout</a>
        </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    <div id="page-content-wrapper">
        <nav class="navbar navbar-expand-lg navbar-light border-bottom" style="background-color:#ce9cdfff">
            <button class="toggler" type="button" id="menu-toggle"  style="background-color: #ce9cdfff;margin-right: 5px;">
                <span data-feather="menu"></span>
            </button>
            <div class="col-md-12 text-center">
                <h3>Suggestion Box</h3>
            </div>
        </nav>

        <div class="container mt-4">
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>

            <!-- Comment Form -->
            <form action="" method="POST">
                <div class="form-group">
                    <label for="comment">Your Suggestion / Feedback</label>
                    <textarea name="comment" id="comment" class="form-control" rows="3" required></textarea>
                </div>
                <button type="submit" name="submit_comment" class="btn " style="background-color:#d48ee5ff">Submit</button>
            </form>

            <hr>

            <!-- Display Comments -->
            <h4>Previous Suggestions</h4>
            <?php if (mysqli_num_rows($commentsResult) > 0): ?>
                <?php while ($row = mysqli_fetch_assoc($commentsResult)): ?>
                    <div class="card mb-2">
                        <div class="card-body">
                            <p class="mb-1"><?php echo nl2br(htmlspecialchars($row['comment'])); ?></p>
                            <small class="text-muted">
                                By <?php echo htmlspecialchars($row['firstname'] . " " . $row['lastname']); ?> 
                                on <?php echo date("d M Y, H:i", strtotime($row['created_at'])); ?>
                            </small>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>No suggestions yet. Be the first to share your thoughts!</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<script src="js/jquery.slim.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script>
    feather.replace();
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
</script>
</body>
</html>
