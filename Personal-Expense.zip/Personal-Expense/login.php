<?php
require('config.php');
session_start();
$errormsg = "";

if (isset($_POST['email']) && isset($_POST['password'])) {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // ==== ADMIN LOGIN CHECK ====$adminEmail = $_SESSION['admin_email'] ?? "Admin";
    if (strtolower($email) === "admin@gmail.com" && $password === "admin") {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['email'] = 'admin@gmail.com';
        header("Location: view_user.php");
        exit();
    }

    // ==== NORMAL USER LOGIN ====
    $email_safe = mysqli_real_escape_string($con, $email);
    $password_safe = mysqli_real_escape_string($con, $password);
    $query = "SELECT * FROM users WHERE email='$email_safe' AND password='" . md5($password_safe) . "'";
    $result = mysqli_query($con, $query) or die(mysqli_error($con));
    if (mysqli_num_rows($result) === 1) {
        $_SESSION['email'] = $email;
        header("Location: index.php");
        exit();
    } else {
        $errormsg = "Wrong email or password.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Login</title>

  <!-- Bootstrap core CSS -->
  <link href="css/bootstrap.css" rel="stylesheet">
  <style>
    body {
  background: url('image.png') no-repeat center center fixed;
  background-size: cover;
  font-family: Arial, sans-serif;
}
    .login-form {
      width: 340px;
      margin: 50px auto;
      font-size: 15px;
    }

    .login-form form {
      margin-bottom: 15px;
      background: #fff;
      box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
      padding: 30px;
     border: 3px solid #d48ee5ff;
    }

    .login-form h2 {
      color: #636363;
      margin: 0 0 15px;
      position: relative;
      text-align: center;
    }

    .login-form h2:before {
      left: 0;
    }

    .login-form h2:after {
      right: 0;
    }

    .login-form .hint-text {
      color: #999;
      margin-bottom: 30px;
      text-align: center;
    }

    .login-form a:hover {
      text-decoration: none;
    }

    .form-control,
    .btn {
      min-height: 38px;
      border-radius: 2px;
    }

    .btn {
      font-size: 15px;
      font-weight: bold;
    }
    .error {
      color: red;
      text-align: center;
      margin-bottom: 10px;
    }
  </style>
</head>

<body>
<div class="login-container">
  <div class="login-form" style="margin-top: 150px" ;>
    <form action="" method="POST" autocomplete="off">
      <h2 class="text-center">Money Map</h2>
      <p class="hint-text">Login Panel</p>
      <?php if (!empty($errormsg)) { ?>
        <div class="error"><?php echo $errormsg; ?></div>
      <?php } ?>
      <div class="form-group">
        <input type="text" name="email" class="form-control" placeholder="Email" required="required">
      </div>
      <div class="form-group">
        <input type="password" name="password" class="form-control" placeholder="Password" required="required">
      </div>
      <div class="form-group">
  <button type="submit" 
          class="btn btn-block" 
          style="border-radius:0%; background-color: hsla(288, 81%, 41%, 1.00); color: #fff; border: none;">
    Login
  </button>
</div>
    </form>
    <p class="text-center">Don't have an account?<a href="register.php" class="text-danger"> Register Here</a></p>
  </div>
 </div>
</body>
<!-- Bootstrap core JavaScript -->
<script src="js/bootstrap.min.js"></script>
<script src="js/feather.min.js"></script>
<script>
  $("#menu-toggle").click(function(e) {
    e.preventDefault();
    $("#wrapper").toggleClass("toggled");
  });
</script>
<script>
  feather.replace()
</script>

</html>
