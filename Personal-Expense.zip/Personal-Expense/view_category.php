<?php
include("session.php");

// ----------------------
// Handle Add Category
// ----------------------
if (isset($_POST['add_category'])) {
    $category_name = trim($_POST['category_name']);

    if (!empty($category_name)) {
        // Check if category already exists
        $check = $con->prepare("SELECT * FROM expense_categories WHERE category_name = ?");
        $check->bind_param("s", $category_name);
        $check->execute();
        $result = $check->get_result();

        if ($result->num_rows > 0) {
            echo "<script>alert('Category already exists');</script>";
        } else {
            $sql = "INSERT INTO expense_categories (category_name) VALUES (?)";
            $stmt = $con->prepare($sql);
            $stmt->bind_param("s", $category_name);

            if ($stmt->execute()) {
    $_SESSION['success_message'] = "Category added successfully!";
    header("Location: view_category.php");
    exit();
} else {
                echo "<script>alert('Error adding category');</script>";
            }
            $stmt->close();
        }
        $check->close();
    } else {
        echo "<script>alert('Please enter a category name');</script>";
    }
}

// ----------------------
// Handle Delete Category
// ----------------------
if (isset($_GET['delete'])) {
    $category_id = $_GET['delete'];

    $sql = "DELETE FROM expense_categories WHERE category_id = ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("i", $category_id);

    if ($stmt->execute()) {
        echo "<script>alert('Category deleted successfully'); window.location='view_category.php';</script>";
        exit();
    } else {
        echo "<script>alert('Error deleting category');</script>";
    }

    $stmt->close();
}

// ----------------------
// Fetch admin info
// ----------------------
$userQuery = mysqli_query($con, "SELECT * FROM admin");
$userData = mysqli_fetch_assoc($userQuery);

$lastname = "Admin";
$useremail = $userData['email'];
$profilePic = !empty($userData['profile_path']) ? 'uploads/' . $userData['profile_path'] : 'uploads/a.jpg';

// ----------------------
// Fetch categories
// ----------------------
$exp_fetched = mysqli_query($con, "SELECT * FROM expense_categories");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Expense Manager - Manage Categories</title>

<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<script src="js/feather.min.js"></script>

<style>
     .shadow-lg {
  box-shadow: 0 1rem 3rem rgba(0, 0, 0, 0.175) !important; /* default */
}
.shadow-lg.custom-color {
  box-shadow: 0 1rem 3rem rgba(188, 18, 210, 0.5) !important;
}
table.table tbody tr:nth-child(odd) {
    background-color: #f3c7efff;
}
table.table tbody tr:nth-child(even) {
    background-color: #ffe6f2;
}
table.table tbody tr:hover {
    background-color: #f397c3ff !important;
}
.try {
  font-size: 28px;
  color: #333;
  padding: 15px 0px 5px 0px;
}
.user {
  text-align: center;
  padding: 20px 0;
}
.user img {
  margin-bottom: 10px;
}
</style>
</head>

<body>
<div class="d-flex" id="wrapper">
    <!-- Sidebar -->
    <div class="border-right" id="sidebar-wrapper" style="background-color: #ce9cdfff">
      <div class="user">
        <img class="img img-fluid rounded-circle" src="<?php echo $profilePic; ?>" width="120" alt="Profile Picture">
        <h5><?php echo htmlspecialchars($lastname); ?></h5>
        <p><?php echo htmlspecialchars($useremail); ?></p>
      </div>
      <div class="sidebar-heading" style="color: #333;">Management</div>
        <div class="list-group list-group-flush">
        <a href="view_user.php"class="list-group-item list-group-item-action"><span data-feather="plus-square"></span>View Users</a>    
        <a href="view_expense.php" class="list-group-item list-group-item-action"><span data-feather="dollar-sign"></span> View Expenses</a>
        <a href="view_category.php" class="list-group-item list-group-item-action"><span data-feather="file-text"></span> View Category</a>
        <a href="view_suggestion.php" class="list-group-item list-group-item-action"><span data-feather="message-square"></span> Suggestion Box</a>  
      </div>
      <div class="sidebar-heading" style="color: #333;">Settings </div>
      <div class="list-group list-group-flush">
        <a href="logout.php" class="list-group-item list-group-item-action"><span data-feather="power"></span> Logout</a>
      </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <div id="page-content-wrapper">
        <nav class="navbar navbar-expand-lg navbar-light border-bottom" style="background-color: #ce9cdfff">
            <button class="toggler" type="button" id="menu-toggle" aria-expanded="false" style="background-color: #ce9cdfff">
                <span data-feather="menu"></span>
            </button>
            <div class="col-md-11 text-center">
                <h3 class="try">Manage Categories</h3>
            </div>
        </nav>

        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <!-- Add Category Form -->
                    <div class="card p-3 mb-3 shadow-lg" style="margin-top:30px">
                        <form method="POST" action="">
                            <div class="form-group">
                                <label for="category_name">New Category Name:</label>
                                <input type="text" name="category_name" id="category_name" class="form-control" required>
                            </div>
                            <button type="submit" name="add_category" class="btn mt-2" style="border-radius: 0%;background-color: #d48ee5ff;border-color:#333">Add Category</button>
                        </form>
                    </div>

                    <!-- Category Table -->
                    <table class="table table-hover table-bordered" style="margin-top:50px">
                        <thead>
                            <tr class="text-center" style="background-color: #ce9cdfff">
                                <th>No</th>
                                <th>Category_ID</th>
                                <th>Category</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $count=1; while ($row = mysqli_fetch_array($exp_fetched)) { ?>
                            <tr>
                                <td class="text-center"><?php echo $count; ?></td>
                                <td class="text-center"><?php echo $row['category_id']; ?></td>
                                <td class="text-center"><?php echo htmlspecialchars($row['category_name']); ?></td>
                                <td class="text-center">
                                    <a href="view_category.php?delete=<?php echo $row['category_id']; ?>" class="btn btn-danger btn-sm" style="border-radius:0%;" onclick="return confirm('Are you sure you want to delete this category?');">Delete</a>
                                </td>
                            </tr>
                        <?php $count++; } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="js/jquery.slim.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/Chart.min.js"></script>
<script>
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
    feather.replace();
</script>
</body>
</html>
