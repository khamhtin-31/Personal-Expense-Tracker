<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

date_default_timezone_set('Asia/Yangon');
include("session.php");
$userQuery = mysqli_query($con, "SELECT firstname, lastname, email, profile_path FROM users WHERE user_id = '$userid'");
$userData = mysqli_fetch_assoc($userQuery);

$firstname = $userData['firstname'];
$lastname = $userData['lastname'];
$useremail = $userData['email'];
$profilePic = !empty($userData['profile_path']) ? 'uploads/' . $userData['profile_path'] : 'uploads/a.jpg';
$update = false;
$del = false;
$expenseamount = "";
$expensedate = date("H:i:s");
$expensecategory = "";

// if (isset($_POST['add1'])) {
//     $expenseamount = $_POST['expenseamount'];
//     $expensecategory = $_POST['expensecategory'];

//     // Convert datetime-local input → MySQL DATETIME format
//     $current = date("Y-m-d H:i:s", strtotime($_POST['expensedate']));

//     $expenses = "INSERT INTO expenses (user_id, expense, expensedate, expensecategory) 
//                   VALUES ('$userid', '$expenseamount', '$current', '$expensecategory')";
//     // $expenses = "Call expenses ('$userid', '$expenseamount', '$current', '$expensecategory')";
//     $result = mysqli_query($con, $expenses) or die("MySQL Error: " . mysqli_error($con));
    
//     header('location: add_expense.php');
// }
if (isset($_POST['add1'])) {
    $expenseamount = $_POST['expenseamount'];
    $expensecategory = $_POST['expensecategory'];
    $current = date("Y-m-d H:i:s", strtotime($_POST['expensedate']));

    // Call the stored procedure
    $stmt = $con->prepare("CALL add_expense(?, ?, ?, ?)");
    $stmt->bind_param("siss", $userid, $expenseamount, $current, $expensecategory);
    $stmt->execute();
    $stmt->close();

    header('location: add_expense.php');
}

if (isset($_POST['add'])) {
    $expenseamount = $_POST['expenseamount'];
    $expensedate = $_POST['expensedate'];
    $expensecategory = $_POST['expensecategory'];

    // Make sure we have a valid category
    if (!empty($expensecategory) && $expensecategory !== 'add_new') {
        $check_sql = "SELECT * FROM expense_categories WHERE category_name = ? AND user_id = ?";
        $stmt = mysqli_prepare($con, $check_sql);
        mysqli_stmt_bind_param($stmt, 'si', $expensecategory, $userid);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($result) === 0) {
            // $insert_sql = "INSERT INTO expense_categories (user_id, category_name) VALUES (?, ?)";
            // $stmt_insert = mysqli_prepare($con, $insert_sql);
            // mysqli_stmt_bind_param($stmt_insert, 'is', $userid, $expensecategory);
            // mysqli_stmt_execute($stmt_insert);
            // mysqli_stmt_close($stmt_insert);
             $stmt = $con->prepare("CALL add_expense_category(?, ?)");
        $stmt->bind_param("is", $userid, $expensecategory);
        $stmt->execute();
        $stmt->close();
        }
        mysqli_stmt_close($stmt);
    } else {
        die("Please add a valid category.");
    }
}

if (isset($_POST['update'])) {
    $id = $_GET['edit'];
    $expenseamount = $_POST['expenseamount'];
    $expensecategory = $_POST['expensecategory'];

    // Convert datetime-local input → MySQL DATETIME format
    $expensedate = date("Y-m-d H:i:s", strtotime($_POST['expensedate']));

    $sql = "UPDATE expenses 
            SET expense='$expenseamount', expensedate='$expensedate', expensecategory='$expensecategory' 
            WHERE user_id='$userid' AND expense_id='$id'";

    if (mysqli_query($con, $sql)) {
        echo "Records were updated successfully.";
    } else {
        echo "ERROR: Could not execute $sql. " . mysqli_error($con);
    }
    
    header('location: manage_expense.php');
}

if (isset($_POST['delete'])) {
    $id = $_GET['delete'];
    $sql = "DELETE FROM expenses WHERE user_id='$userid' AND expense_id='$id'";
    if (mysqli_query($con, $sql)) {
        echo "Records were deleted successfully.";
    } else {
        echo "ERROR: Could not execute $sql. " . mysqli_error($con);
    }
    header('location: manage_expense.php');
}

// Load expense data for edit
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $update = true;
    $record = mysqli_query($con, "SELECT * FROM expenses WHERE user_id='$userid' AND expense_id=$id");
    if (mysqli_num_rows($record) == 1) {
        $n = mysqli_fetch_array($record);
        $expenseamount = $n['expense'];
        $expensedate = $n['expensedate'];
        $expensecategory = $n['expensecategory'];
    } else {
        echo ("WARNING: AUTHORIZATION ERROR: Trying to Access Unauthorized data");
    }
}

// Load expense data for delete confirmation
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $del = true;
    $record = mysqli_query($con, "SELECT * FROM expenses WHERE user_id='$userid' AND expense_id=$id");
    if (mysqli_num_rows($record) == 1) {
        $n = mysqli_fetch_array($record);
        $expenseamount = $n['expense'];
        $expensedate = $n['expensedate'];
        $expensecategory = $n['expensecategory'];
    } else {
        echo ("WARNING: AUTHORIZATION ERROR: Trying to Access Unauthorized data");
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Expense Manager - Dashboard</title>
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <script src="js/feather.min.js"></script>
    <style>
        .shadow-lg { box-shadow: 0 1rem 3rem rgba(0,0,0,0.175) !important; }
        .shadow-lg.custom-color { box-shadow: 0 1rem 3rem rgba(188,18,210,0.5) !important; }
        .try { font-size: 28px; color:#333; padding:15px 70px 5px 0; }
        .gap-2 { gap:0.5rem; }
    </style>
</head>
<body>
<div class="d-flex" id="wrapper">
    <!-- Sidebar -->
    <div class="border-right" id="sidebar-wrapper" style="background-color:#ce9cdfff">
        <div class="user">
            <img class="img img-fluid rounded-circle" src="<?php echo $profilePic; ?>" width="120" alt="Profile Picture">
            <h5><?php echo $username ?></h5>
            <p><?php echo $useremail ?></p>
        </div>
        <div class="sidebar-heading" style="color: #333";>Management</div>
        <div class="list-group list-group-flush">
            <a href="index.php" class="list-group-item list-group-item-action"><span data-feather="home"></span> Dashboard</a>
            <a href="add_expense.php" class="list-group-item list-group-item-action sidebar-active"><span data-feather="plus-square"></span> Add Expenses</a>
            <a href="manage_expense.php" class="list-group-item list-group-item-action "><span data-feather="dollar-sign"></span> Manage Expenses</a>
            <a href="expensereport.php" class="list-group-item list-group-item-action"><span data-feather="file-text"></span> Expense Report</a>
            <a href="suggestion.php" class="list-group-item list-group-item-action"><span data-feather="message-square"></span> Suggestion Box</a>
        </div>
        <div class="sidebar-heading" style="color:#333">Settings </div>
        <div class="list-group list-group-flush">
            <a href="profile.php" class="list-group-item list-group-item-action "><span data-feather="user"></span> Profile</a>
            <a href="logout.php" class="list-group-item list-group-item-action "><span data-feather="power"></span> Logout</a>
        </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    <div id="page-content-wrapper">
        <nav class="navbar navbar-expand-lg navbar-light border-bottom" style="background-color:#ce9cdfff">
            <button class="toggler" type="button" id="menu-toggle" aria-expanded="false" style="background-color: #ce9cdfff;margin-right: 5px;">
                <span data-feather="menu"></span>
            </button>
            <div class="col-md-12 text-center">
                <h3 class="try">Add Your Daily Expenses</h3>
            </div>
            <hr>
        </nav>

        <div class="container">
            <div class="row ">
                <div class="col-md-3"></div>
                <div class="col-md shadow-lg custom-color" style="margin-top:80px;">
                    <form action="" method="POST" style="margin-top:30px;padding:30px;padding-bottom:10px">
                        <div class="form-group row" style="margin-top: 20px;">
                            <label for="expenseamount" class="col-sm-6 col-form-label"><b>Enter Amount</b></label>
                            <div class="col-md-6">
                                <input type="number" class="form-control col-sm-12" value="<?php echo $expenseamount; ?>" id="expenseamount" name="expenseamount" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="expensedate" class="col-sm-6 col-form-label"><b>Date</b></label>
                            <div class="col-md-6">
                                <input type="datetime-local" class="form-control col-sm-12" 
                                       value="<?php echo isset($expensedate) ? date('Y-m-d\TH:i', strtotime($expensedate)) : ''; ?>" 
                                       name="expensedate" id="expensedate" required>
                            </div>
                        </div>
                        <fieldset class="form-group">
                            <div class="row">
                                <label class="col-form-label col-sm-6 pt-0"><b>Category</b></label>
                                <div class="col-md d-flex align-items-center gap-2">
                                    <select class="form-control" id="expensecategory" name="expensecategory" required>
                                        <?php
                                        $categories_query = "SELECT * FROM expense_categories";
                                        $categories_result = mysqli_query($con, $categories_query);
                                        while ($row = mysqli_fetch_assoc($categories_result)) {
                                            $category_name = htmlspecialchars($row['category_name']);
                                            $selected = ($category_name === $expensecategory) ? 'selected' : '';
                                            echo "<option value=\"$category_name\" $selected>$category_name</option>";
                                        }
                                        ?>
                                        <option value="add_new">+ Add New Category</option>
                                    </select>
                                    <input type="text" id="new_category" name="new_category" class="form-control" placeholder="Enter new category" style="display:none; width: 200px;">
                                    <button type="button" id="add_category_btn" class="btn " style="display:none;background-color:#d48ee5ff">Add</button>
                                </div>
                            </div>
                        </fieldset>

                        <div class="form-group row">
                            <div class="col-md-12 text-right">
                                <?php if ($update == true) : ?>
                                    <button class="btn btn-lg btn-block " style="border-radius: 0%;background-color:#ce9cdfff" type="submit" name="update">Update</button>
                                <?php elseif ($del == true) : ?>
                                    <button class="btn btn-lg btn-block btn-danger" style="border-radius: 0%;" type="submit" name="delete">Delete</button>
                                <?php else : ?>
                                    <button type="submit" name="add1" class="btn btn-lg btn-block " style="border-radius: 0%;background-color: #d48ee5ff;border-color:#333">Add Expense</button>
                                <?php endif ?>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="col-md-3"></div>
            </div>
        </div>
    </div>
</div>

<script src="js/jquery.slim.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/Chart.min.js"></script>
<script src="js/popper.min.js"></script>
<script>
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
    feather.replace();
</script>
<script>
    const expenseCategorySelect = document.getElementById('expensecategory');
    const newCategoryInput = document.getElementById('new_category');
    const addCategoryBtn = document.getElementById('add_category_btn');
    expenseCategorySelect.addEventListener('change', function() {
        if (this.value === 'add_new') {
            newCategoryInput.style.display = 'inline-block';
            addCategoryBtn.style.display = 'inline-block';
            newCategoryInput.required = true;
        } else {
            newCategoryInput.style.display = 'none';
            addCategoryBtn.style.display = 'none';
            newCategoryInput.required = false;
            newCategoryInput.value = '';
        }
    });

    addCategoryBtn.addEventListener('click', function() {
        const newCategory = newCategoryInput.value.trim();
        if (!newCategory) {
            alert('Please enter a category name.');
            return;
        }

        for (let option of expenseCategorySelect.options) {
            if (option.value.toLowerCase() === newCategory.toLowerCase()) {
                alert('This category already exists.');
                return;
            }
        }

        const newOption = document.createElement('option');
        newOption.value = newCategory;
        newOption.text = newCategory;
        expenseCategorySelect.add(newOption, expenseCategorySelect.options[expenseCategorySelect.options.length - 1]);
        expenseCategorySelect.value = newCategory;

        newCategoryInput.value = '';
        newCategoryInput.style.display = 'none';
        addCategoryBtn.style.display = 'none';
        newCategoryInput.required = false;
    });
</script>
</body>
</html>
