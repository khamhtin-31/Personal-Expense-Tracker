USE dailyexpense;

DELIMITER $$

-- ===========================
-- STORED PROCEDURE
-- ===========================
-- Procedure to add a new expense with auto timestamp
CREATE PROCEDURE add_expense(
    IN p_user_id INT,
    IN p_amount DECIMAL(10,2),
    IN p_category_id INT,
    IN p_note VARCHAR(255)
)
BEGIN
    DECLARE category_name VARCHAR(255);

    -- Get category name from expense_categories
    SELECT category_name INTO category_name
    FROM expense_categories
    WHERE category_id = p_category_id;

    -- Insert new expense (auto set expensedate to NOW)
    INSERT INTO expenses (user_id, expense, expensedate, expensecategory)
    VALUES (p_user_id, p_amount, NOW(), category_name);
END $$


-- ===========================
-- VIEW
-- ===========================
-- Monthly expense summary per user and category
CREATE OR REPLACE VIEW monthly_expenses AS
SELECT 
    u.user_id,
    CONCAT(u.firstname, ' ', u.lastname) AS username,
    DATE_FORMAT(e.expensedate, '%Y-%m') AS month,
    e.expensecategory,
    SUM(e.expense) AS total_spent
FROM expenses e
JOIN users u ON e.user_id = u.user_id
GROUP BY u.user_id, month, e.expensecategory
ORDER BY month DESC, total_spent DESC $$


-- ===========================
-- FUNCTION
-- ===========================
-- Function to check if a user has exceeded a spending limit in a category this month
CREATE FUNCTION is_over_budget(p_user_id INT, p_category VARCHAR(255), p_limit DECIMAL(10,2))
RETURNS BOOLEAN
DETERMINISTIC
BEGIN
    DECLARE total_spent DECIMAL(10,2);

    SELECT SUM(expense) INTO total_spent
    FROM expenses
    WHERE user_id = p_user_id
      AND expensecategory = p_category
      AND DATE_FORMAT(expensedate, '%Y-%m') = DATE_FORMAT(NOW(), '%Y-%m');

    RETURN IFNULL(total_spent,0) > p_limit;
END $$


-- ===========================
-- EVENT
-- ===========================
-- Example: Insert a reminder note for each user at the start of the month
CREATE EVENT IF NOT EXISTS monthly_reminder
ON SCHEDULE EVERY 1 MONTH
STARTS (CURRENT_DATE + INTERVAL 1 MONTH)
DO
    INSERT INTO suggestions (user_id, comment)
    SELECT user_id, 'New month started! Don’t forget to set your budget.'
    FROM users $$

DELIMITER ;
