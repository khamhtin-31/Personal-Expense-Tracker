-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 26, 2025 at 06:59 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `moneymap`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_expense` (IN `p_user_id` VARCHAR(15), IN `p_expense` INT(20), IN `p_expensedate` DATETIME, IN `p_expensecategory` VARCHAR(50))   BEGIN
    INSERT INTO expenses (user_id, expense, expensedate, expensecategory)
    VALUES (p_user_id, p_expense, p_expensedate, p_expensecategory);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `add_expense_category` (IN `p_user_id` INT, IN `p_category_name` VARCHAR(255))   BEGIN
    -- Only insert if category does not already exist for this user
    IF NOT EXISTS (
        SELECT 1 FROM expense_categories 
        WHERE user_id = p_user_id AND category_name = p_category_name
    ) THEN
        INSERT INTO expense_categories (user_id, category_name)
        VALUES (p_user_id, p_category_name);
    END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `add_suggestion` (IN `p_user_id` INT, IN `p_comment` TEXT)   BEGIN
    INSERT INTO suggestions (user_id, comment)
    VALUES (p_user_id, p_comment);
END$$

--
-- Functions
--
CREATE DEFINER=`root`@`localhost` FUNCTION `is_over_budget` (`p_user_id` INT, `p_category` VARCHAR(255), `p_limit` DECIMAL(10,2)) RETURNS TINYINT(1) DETERMINISTIC BEGIN
    DECLARE total_spent DECIMAL(10,2);

    SELECT SUM(expense) INTO total_spent
    FROM expenses
    WHERE user_id = p_user_id
      AND expensecategory = p_category
      AND DATE_FORMAT(expensedate, '%Y-%m') = DATE_FORMAT(NOW(), '%Y-%m');

    RETURN IFNULL(total_spent,0) > p_limit;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `password`, `email`) VALUES
(1, 'Admin', 'admin', 'admin@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE `expenses` (
  `expense_id` int(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `expense` int(20) NOT NULL,
  `expensedate` datetime DEFAULT NULL,
  `expensecategory` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `expenses`
--

INSERT INTO `expenses` (`expense_id`, `user_id`, `expense`, `expensedate`, `expensecategory`) VALUES
(123, 13, 5000, '2025-08-25 23:02:00', 'Medicine'),
(124, 13, 7000, '2025-07-24 23:02:00', 'Food'),
(125, 13, 2000, '2025-08-25 23:03:00', 'Medicine'),
(126, 13, 50000, '2025-08-26 13:01:00', 'Medicine'),
(136, 13, 40000, '2025-08-26 19:13:00', 'glass'),
(137, 13, 2000, '2025-08-07 19:15:00', 'Entertainment');

--
-- Triggers `expenses`
--
DELIMITER $$
CREATE TRIGGER `set_expense_date_before_insert` BEFORE INSERT ON `expenses` FOR EACH ROW BEGIN
    IF NEW.expensedate IS NULL OR NEW.expensedate = '' THEN
        SET NEW.expensedate = DATE_FORMAT(NOW(), '%Y-%m-%d');
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `update_expense_date_before_update` BEFORE UPDATE ON `expenses` FOR EACH ROW BEGIN
    IF NEW.expensedate IS NULL OR NEW.expensedate = '' THEN
        SET NEW.expensedate = DATE_FORMAT(NOW(), '%Y-%m-%d');
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `expense_categories`
--

CREATE TABLE `expense_categories` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `expense_categories`
--

INSERT INTO `expense_categories` (`category_id`, `category_name`) VALUES
(12, 'book'),
(5, 'Clothings'),
(9, 'cup'),
(13, 'egg'),
(4, 'Entertainment'),
(2, 'Food'),
(11, 'glasses'),
(7, 'Household Items'),
(1, 'Medicine'),
(8, 'Others'),
(6, 'Rent'),
(14, 'tv');

-- --------------------------------------------------------

--
-- Stand-in structure for view `monthly_expenses`
-- (See below for the actual view)
--
CREATE TABLE `monthly_expenses` (
`user_id` int(11)
,`username` varchar(76)
,`month` varchar(7)
,`expensecategory` varchar(50)
,`total_spent` decimal(41,0)
);

-- --------------------------------------------------------

--
-- Table structure for table `ratings`
--

CREATE TABLE `ratings` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL,
  `note` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `suggestions`
--

CREATE TABLE `suggestions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `suggestions`
--

INSERT INTO `suggestions` (`id`, `user_id`, `comment`, `created_at`) VALUES
(1, 16, 'ytu', '2025-08-26 12:35:55'),
(2, 13, 'Good luck with everything', '2025-08-26 12:55:09');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(25) NOT NULL,
  `email` varchar(50) NOT NULL,
  `profile_path` varchar(255) DEFAULT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `firstname`, `lastname`, `email`, `profile_path`, `password`) VALUES
(13, 'Ei', 'Phoo', 'ei@gmail.com', 'zora.jpg', '1ee2225a0118c6a8ff464cf2926cf352'),
(14, 'Yu', 'Yu', 'yu@gmail.com', NULL, '385d04e7683a033fcc6c6654529eb7e9'),
(15, 'Moe', 'Moe', 'moe@gmail.com', NULL, '7f33334d4c2f6dd6ffc701944cec2f1c');

-- --------------------------------------------------------

--
-- Structure for view `monthly_expenses`
--
DROP TABLE IF EXISTS `monthly_expenses`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `monthly_expenses`  AS SELECT `u`.`user_id` AS `user_id`, concat(`u`.`firstname`,' ',`u`.`lastname`) AS `username`, date_format(`e`.`expensedate`,'%Y-%m') AS `month`, `e`.`expensecategory` AS `expensecategory`, sum(`e`.`expense`) AS `total_spent` FROM (`expenses` `e` join `users` `u` on(`e`.`user_id` = `u`.`user_id`)) GROUP BY `u`.`user_id`, date_format(`e`.`expensedate`,'%Y-%m'), `e`.`expensecategory` ORDER BY date_format(`e`.`expensedate`,'%Y-%m') DESC, sum(`e`.`expense`) DESC ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`expense_id`),
  ADD KEY `fk_expenses_user` (`user_id`);

--
-- Indexes for table `expense_categories`
--
ALTER TABLE `expense_categories`
  ADD PRIMARY KEY (`category_id`),
  ADD KEY `category_id` (`category_name`);

--
-- Indexes for table `ratings`
--
ALTER TABLE `ratings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `suggestions`
--
ALTER TABLE `suggestions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `expenses`
--
ALTER TABLE `expenses`
  MODIFY `expense_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=138;

--
-- AUTO_INCREMENT for table `expense_categories`
--
ALTER TABLE `expense_categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `ratings`
--
ALTER TABLE `ratings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `suggestions`
--
ALTER TABLE `suggestions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `expenses`
--
ALTER TABLE `expenses`
  ADD CONSTRAINT `fk_expenses_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

DELIMITER $$
--
-- Events
--
CREATE DEFINER=`root`@`localhost` EVENT `monthly_reminder` ON SCHEDULE EVERY 1 MONTH STARTS '2025-09-26 00:00:00' ON COMPLETION NOT PRESERVE ENABLE DO INSERT INTO suggestions (user_id, comment)
    SELECT user_id, 'New month started! Don’t forget to set your budget.'
    FROM users$$

DELIMITER ;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
