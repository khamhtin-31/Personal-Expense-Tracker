<?php
include("session.php");
// include your DB connection file

if (isset($_GET['delete'])) {
    $user_id = $_GET['delete'];

    // Prepare the delete query
    $sql = "DELETE FROM users WHERE user_id = ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("i", $user_id);
    
    if ($stmt->execute()) {
    header("Location: view_user.php?msg=deleted");
    exit();
} else {
    header("Location: view_user.php?msg=error");
    exit();
}


    $stmt->close();
    $con->close();
}


// Fetch admin info
$userQuery = mysqli_query($con, "SELECT * FROM admin");
$userData = mysqli_fetch_assoc($userQuery);

$lastname ="Admin";
$useremail = $userData['email'];
$profilePic = !empty($userData['profile_path']) ? 'uploads/' . $userData['profile_path'] : 'uploads/a.jpg';

// Get selected sort option
$selectedSort = isset($_GET['sort']) ? $_GET['sort'] : 'none';

// Build ORDER BY clause
switch ($selectedSort) {
    case 'name_asc':
        $orderByClause = "ORDER BY firstname ASC"; // A-Z
        break;
    case 'name_desc':
        $orderByClause = "ORDER BY firstname DESC"; // Z-A
        break;
    case 'none':
    default:
        $orderByClause = "ORDER BY user_id DESC"; // Most recent
        break;
}

// Fetch users with sorting applied
$exp_fetched = mysqli_query($con, "SELECT user_id, firstname, lastname, email, profile_path FROM users $orderByClause");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Expense Manager - Manage Expenses</title>

<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<script src="js/feather.min.js"></script>

<style>

    .shadow-lg {
  box-shadow: 0 1rem 3rem rgba(0, 0, 0, 0.175) !important; /* default */
}

/* custom version */
.shadow-lg.custom-color {
  box-shadow: 0 1rem 3rem rgba(188, 18, 210, 0.5) !important; /* blue example */
}

      table.table tbody tr:nth-child(odd) {
    background-color: #f3c7efff; /* light gray */
  }
  table.table tbody tr:nth-child(even) {
    background-color: #ffe6f2; /* white */
  }

  /* Example: highlight on hover */
  table.table tbody tr:hover {
    background-color: #f397c3ff !important; /* light pink */
  }
.try {
  font-size: 28px;
  color: #333;
  padding: 15px 0px 5px 0px;
}
.user {
  text-align: center;
  padding: 20px 0;
}
.user img {
  margin-bottom: 10px;
}
</style>
</head>

<body>
<div class="d-flex" id="wrapper">
    <!-- Sidebar -->
    <div class="border-right" id="sidebar-wrapper" style="background-color: #ce9cdfff">
      <div class="user">
        <img class="img img-fluid rounded-circle" src="<?php echo $profilePic; ?>" width="120" alt="Profile Picture">
        <h5><?php echo htmlspecialchars($lastname); ?></h5>
        <p><?php echo htmlspecialchars($useremail); ?></p>
      </div>
      <div class="sidebar-heading" style="color:#333">Management</div>
        <div class="list-group list-group-flush">
        <a href="view_user.php"class="list-group-item list-group-item-action"><span data-feather="plus-square"></span>View Users</a>    
        <a href="view_expense.php" class="list-group-item list-group-item-action"><span data-feather="dollar-sign"></span> View Expenses</a>
        <a href="view_category.php" class="list-group-item list-group-item-action"><span data-feather="file-text"></span> View Category</a>
        <a href="view_suggestion.php" class="list-group-item list-group-item-action"><span data-feather="message-square"></span> Suggestion Box</a>  
      </div>
      <div class="sidebar-heading" style="color:#333">Settings </div>
      <div class="list-group list-group-flush">
        <a href="logout.php" class="list-group-item list-group-item-action"><span data-feather="power"></span> Logout</a>
      </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <div id="page-content-wrapper">
        <nav class="navbar navbar-expand-lg navbar-light border-bottom" style="background-color: #ce9cdfff">
            <button class="toggler" type="button" id="menu-toggle" style="background-color: #ce9cdfff" aria-expanded="false">
                <span data-feather="menu"></span>
            </button>
            <div class="col-md-11 text-center">
                <h3 class="try">Manage Expenses</h3>
            </div>
        </nav>

        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <form method="GET" action="">
                        <div class="form-group mt-3">
                            <label for="sort">Sort By:</label>
                            <select class="form-control shadow-lg" id="sort" name="sort" onchange="this.form.submit()">
                                <option value="none" <?php if ($selectedSort === 'none') echo 'selected'; ?>>Recent User</option>
                                <option value="name_asc" <?php if ($selectedSort === 'name_asc') echo 'selected'; ?>>Name (A-Z)</option>
                                <option value="name_desc" <?php if ($selectedSort === 'name_desc') echo 'selected'; ?>>Name (Z-A)</option>
                            </select>
                        </div>
                    </form>

                    <br>
                    <table class="table table-hover table-bordered" style="background-color: #ce9cdfff;">
                        <thead>
                            <tr class="text-center">
                                <th>No</th>
                                <th>User ID</th>
                                <th>First name</th>
                                <th>Last name</th>
                                <th>Email</th>
                                <th>Profile Path</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $count=1; while ($row = mysqli_fetch_array($exp_fetched)) { ?>
                            <tr>
                                <td class="text-center"><?php echo $count; ?></td>
                                <td class="text-center"><?php echo $row['user_id']; ?></td>
                                <td class="text-center"><?php echo $row['firstname']; ?></td>
                                <td class="text-center"><?php echo $row['lastname']; ?></td>
                                <td class="text-center"><?php echo $row['email']; ?></td>
                                <td class="text-center"><?php echo $row['profile_path']; ?></td>
                                <td class="text-center">
                                    <a href="view_user.php?delete=<?php echo $row['user_id']; ?>" class="btn btn-danger btn-sm" style="border-radius:0%;" onclick="return confirm('Are you sure you want to delete this expense?');">Delete</a>
                                </td>
                            </tr>
                        <?php $count++; } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
 <script>
  document.querySelectorAll(".list-group-item").forEach(item => {
    item.addEventListener("click", function () {
      document.querySelectorAll(".list-group-item").forEach(link => 
        link.classList.remove("active")
      );
      this.classList.add("active");
    });
  });
</script>
<script src="js/jquery.slim.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/Chart.min.js"></script>
<script>
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
    feather.replace();
</script>
</body>
</html>
