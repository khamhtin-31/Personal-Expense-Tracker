/Users/siesar/Downloads/dailyexpense.sql-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 25, 2025 at 09:05 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dailyexpense`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(30) NOT NULL,
  `name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `password`, `email`) VALUES
(1, 'Admin', 'admin', 'admin@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE `expenses` (
  `expense_id` int(20) NOT NULL,
  `user_id` varchar(15) NOT NULL,
  `expense` int(20) NOT NULL,
  `expensedate` datetime DEFAULT NULL,
  `expensecategory` varchar(50) NOT NULL
   FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `expenses`
--

INSERT INTO `expenses` (`expense_id`, `user_id`, `expense`, `expensedate`, `expensecategory`) VALUES
(101, '9', 789, '2023-08-31 00:00:00', 'Medicine'),
(102, '9', 3, '2023-08-31 00:00:00', 'Entertainment'),
(103, '9', 469, '2023-08-29 00:00:00', 'Clothings'),
(104, '9', 985, '2023-08-25 00:00:00', 'Entertainment'),
(105, '12', 3, '2023-08-31 00:00:00', 'Clothings'),
(106, '12', 89, '2023-08-16 00:00:00', 'Bills & Recharges'),
(107, '9', 3, '2023-09-06 00:00:00', 'Clothings'),
(108, '9', 300, '2023-07-04 00:00:00', 'Food'),
(109, '9', 456, '2023-09-01 00:00:00', 'Clothings'),
(110, '9', 3, '2023-08-28 00:00:00', 'Entertainment'),
(111, '9', 300, '2023-09-03 00:00:00', 'Clothings'),
(112, '9', 789, '2021-06-03 00:00:00', 'Medicine'),
(113, '9', 756, '2021-02-23 00:00:00', 'Entertainment'),
(114, '9', 123, '2022-09-03 00:00:00', 'Medicine'),
(115, '9', 256, '2021-09-07 00:00:00', 'Medicine'),
(116, '9', 798, '2023-09-04 00:00:00', 'Medicine'),
(117, '9', 45, '2023-08-28 00:00:00', 'Entertainment'),
(118, '9', 50, '2023-10-20 00:00:00', 'Medicine'),
(119, '9', 786, '2023-10-20 00:00:00', 'Food'),
(120, '9', 1000, '2023-10-04 00:00:00', 'Entertainment'),
(121, '9', 500, '2023-10-19 00:00:00', 'Clothings'),
(122, '9', 426, '2023-10-16 00:00:00', 'Household Items'),
(123, '13', 800, '2025-08-19 23:56:00', 'Medicine'),
(124, '13', 30000, '2025-08-26 01:03:00', 'Entertainment'),
(126, '13', 12000, '2025-08-25 01:26:00', 'lipstick');

--
-- Triggers `expenses`
--
DELIMITER $$
CREATE TRIGGER `set_expense_date_before_insert` BEFORE INSERT ON `expenses` FOR EACH ROW BEGIN
    -- Automatically set expensedate to today's date if not provided
    IF NEW.expensedate IS NULL OR NEW.expensedate = '' THEN
        SET NEW.expensedate = DATE_FORMAT(NOW(), '%Y-%m-%d');
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `update_expense_date_before_update` BEFORE UPDATE ON `expenses` FOR EACH ROW BEGIN
    -- Automatically set expensedate to today's date if not provided in update
    IF NEW.expensedate IS NULL OR NEW.expensedate = '' THEN
        SET NEW.expensedate = DATE_FORMAT(NOW(), '%Y-%m-%d');
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `expense_categories`
--

CREATE TABLE `expense_categories` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `expense_categories`
--

INSERT INTO `expense_categories` (`category_id`, `category_name`) VALUES
(1, 'Medicine'),
(2, 'Food'),
(3, 'Bills & Recharges'),
(4, 'Entertainment'),
(5, 'Clothings'),
(6, 'Rent'),
(7, 'Household Items'),
(8, 'Others');

-- --------------------------------------------------------
-- Create the procedure
DELIMITER //
CREATE PROCEDURE `add_expense` (
    IN p_user_id VARCHAR(15),
    IN p_expense INT(20),
    IN p_expensedate DATETIME,
    IN p_expensecategory VARCHAR(50)
)
BEGIN
    INSERT INTO expenses (user_id, expense, expensedate, expensecategory)
    VALUES (p_user_id, p_expense, p_expensedate, p_expensecategory);
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE `add_expense_category` (
    IN p_user_id INT,
    IN p_category_name VARCHAR(255)
)
BEGIN
    -- Only insert if category does not already exist for this user
    IF NOT EXISTS (
        SELECT 1 FROM expense_categories 
        WHERE user_id = p_user_id AND category_name = p_category_name
    ) THEN
        INSERT INTO expense_categories (user_id, category_name)
        VALUES (p_user_id, p_category_name);
    END IF;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE `add_suggestion` (
    IN p_user_id INT,
    IN p_comment TEXT
)
BEGIN
    INSERT INTO suggestions (user_id, comment)
    VALUES (p_user_id, p_comment);
END //
DELIMITER ;
--
-- Table structure for table `ratings`
--

CREATE TABLE `ratings` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL,
  `note` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `suggestions`
--

CREATE TABLE `suggestions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `suggestions`
--

INSERT INTO `suggestions` (`id`, `user_id`, `comment`, `created_at`) VALUES
(1, 13, 'Good luck for everything', '2025-08-25 17:34:47');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(25) NOT NULL,
  `email` varchar(50) NOT NULL,
  `profile_path` varchar(255) DEFAULT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

CREATE INDEX category_id ON expense_categories(category_name);

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `firstname`, `lastname`, `email`, `profile_path`, `password`) VALUES
(9, 'Anjalita', 'Fernandes', 'anjalita@sjec.in', NULL, 'b7161ae9080c2604adb157463312ed47'),
(12, 'Ebey', 'Joe Regi', 'ejr@sjec.in', NULL, '25d55ad283aa400af464c76d713c07ad'),
(13, 'Yu', 'Sie', 'yusie@gmail.com', 'n.jpg', '2530104dff0f0e4dd642c861c4e5c65f'),
(14, 'Sang', 'Won', 'sang@gmail.com', NULL, '9d7652591c3f0a3f1c7de544b9adec55'),
(15, 'Leo', 'Lee', 'leo@gmail.com', NULL, '0f759dd1ea6c4c76cedc299039ca4f23'),
(16, 'An', 'Xin', 'anxin@gmail.com', NULL, 'f079e067a5425f470cb313ae58c5a5ae');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`expense_id`);

--
-- Indexes for table `expense_categories`
--
ALTER TABLE `expense_categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `ratings`
--
ALTER TABLE `ratings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `suggestions`
--
ALTER TABLE `suggestions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `expenses`
--
ALTER TABLE `expenses`
  MODIFY `expense_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=127;

--
-- AUTO_INCREMENT for table `expense_categories`
--
ALTER TABLE `expense_categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `ratings`
--
ALTER TABLE `ratings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `suggestions`
--
ALTER TABLE `suggestions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
USE dailyexpense;

DELIMITER $$

-- ===========================
-- STORED PROCEDURE
-- ===========================
-- Procedure to add a new expense with auto timestamp
CREATE PROCEDURE add_expense(
    IN p_user_id INT,
    IN p_amount DECIMAL(10,2),
    IN p_category_id INT,
    IN p_note VARCHAR(255)
)
BEGIN
    DECLARE category_name VARCHAR(255);

    -- Get category name from expense_categories
    SELECT category_name INTO category_name
    FROM expense_categories
    WHERE category_id = p_category_id;

    -- Insert new expense (auto set expensedate to NOW)
    INSERT INTO expenses (user_id, expense, expensedate, expensecategory)
    VALUES (p_user_id, p_amount, NOW(), category_name);
END $$


-- ===========================
-- VIEW
-- ===========================
-- Monthly expense summary per user and category
CREATE OR REPLACE VIEW monthly_expenses AS
SELECT 
    u.user_id,
    CONCAT(u.firstname, ' ', u.lastname) AS username,
    DATE_FORMAT(e.expensedate, '%Y-%m') AS month,
    e.expensecategory,
    SUM(e.expense) AS total_spent
FROM expenses e
JOIN users u ON e.user_id = u.user_id
GROUP BY u.user_id, month, e.expensecategory
ORDER BY month DESC, total_spent DESC $$


-- ===========================
-- FUNCTION
-- ===========================
-- Function to check if a user has exceeded a spending limit in a category this month
CREATE FUNCTION is_over_budget(p_user_id INT, p_category VARCHAR(255), p_limit DECIMAL(10,2))
RETURNS BOOLEAN
DETERMINISTIC
BEGIN
    DECLARE total_spent DECIMAL(10,2);

    SELECT SUM(expense) INTO total_spent
    FROM expenses
    WHERE user_id = p_user_id
      AND expensecategory = p_category
      AND DATE_FORMAT(expensedate, '%Y-%m') = DATE_FORMAT(NOW(), '%Y-%m');

    RETURN IFNULL(total_spent,0) > p_limit;
END $$


-- ===========================
-- EVENT
-- ===========================
-- Example: Insert a reminder note for each user at the start of the month
CREATE EVENT IF NOT EXISTS monthly_reminder
ON SCHEDULE EVERY 1 MONTH
STARTS (CURRENT_DATE + INTERVAL 1 MONTH)
DO
    INSERT INTO suggestions (user_id, comment)
    SELECT user_id, 'New month started! Don’t forget to set your budget.'
    FROM users $$

DELIMITER ;
