<?php
date_default_timezone_set('Asia/Yangon');
include("session.php");

// Profile info (optional, if you want to show user in header)
$userQuery = mysqli_query($con, "SELECT firstname, lastname, email, profile_path FROM users WHERE user_id = '$userid'");
$userData = mysqli_fetch_assoc($userQuery);

$username = $userData['firstname'] . " " . $userData['lastname'];
$useremail = $userData['email'];
$profilePic = !empty($userData['profile_path']) ? 'uploads/' . $userData['profile_path'] : 'uploads/default_profile.png';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>About Us -Money Map</title>
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <style>
        .about-section {
            background: linear-gradient(135deg, #4f9aff, rgba(226, 36, 213, 1));
            color: white;
            padding: 80px 0;
            text-align: center;
        }
        .about-section h1 {
            font-size: 3rem;
            font-weight: bold;
        }
        .about-section p {
            max-width: 700px;
            margin: auto;
            font-size: 1.1rem;
            opacity: 0.9;
        }
        .team-section {
            padding: 60px 0;
        }
        .team-card {
            border: 3px solid #d48ee5ff;
            border-radius: 30px;
            transition: transform 0.3s ease;
        }
        .team-card:hover {
            transform: translateY(-5px);
        }
        .team-card img {
            border-radius: 50%;
        }
      
    </style>
</head>
<body>
<div class="d-flex" id="wrapper">

    <!-- Sidebar -->
    <!-- <div class="border-right" id="sidebar-wrapper">
        <div class="user text-center p-3">
            <img class="img img-fluid rounded-circle mb-2" src="<?php echo $profilePic; ?>" width="120">
            <h5><?php echo htmlspecialchars($username); ?></h5>
            <p><?php echo htmlspecialchars($useremail); ?></p>
        </div>
        <div class="sidebar-heading">Menu</div>
        <div class="list-group list-group-flush">
            <a href="index.php" class="list-group-item list-group-item-action"><span data-feather="home"></span> Dashboard</a>
            <a href="about_us.php" class="list-group-item list-group-item-action sidebar-active"><span data-feather="info"></span> About Us</a>
        </div>
        <div class="sidebar-heading">Settings</div>
        <div class="list-group list-group-flush">
            <a href="profile.php" class="list-group-item list-group-item-action"><span data-feather="user"></span> Profile</a>
            <a href="logout.php" class="list-group-item list-group-item-action"><span data-feather="power"></span> Logout</a>
        </div>
    </div> -->

    <!-- Page Content -->
    <div id="page-content-wrapper">
       <nav class="navbar navbar-expand-lg navbar-light border-bottom">
    <div class="container-fluid">
        <div class="col-md-12 text-center">
            <!-- <h3 class="m-0">About Us</h3> -->
        </div>
        <!-- Login button at right -->
        <a href="login.php" class="btn btn-outline-primary ms-auto">
            login
        </a>
    </div>
</nav>


        <!-- About Section -->
        <section class="about-section">
            <div class="container">
                <h1>About Our Money Map</h1>
                <p>
                    Money Map is your ultimate tool for taking control of your finances.  
                    Designed with simplicity and efficiency in mind, it helps you track daily expenses,  
                    analyze spending habits, and achieve your financial goals without stress.  
                    Whether you're managing personal budgets or keeping an eye on business spending,  
                    this platform makes money management effortless and insightful.
                </p>
            </div>
        </section>

        <!-- Mission & Vision -->
        <section class="container text-center my-5">
            <div class="row">
                <div class="col-md-6 mb-4">
                    <div class="p-4 border rounded shadow-lg h-100 ">
                        <h3 class="text-primary">Our Mission</h3>
                        <p>
                            To empower individuals and businesses to make smarter financial decisions  
                            by providing an easy-to-use, accurate, and secure expense tracking solution.
                        </p>
                    </div>
                </div>
                <div class="col-md-6 mb-4">
                    <div class="p-4 border rounded shadow-lg h-100">
                        <h3 class="text-success">Our Vision</h3>
                        <p>
                            To become the most trusted personal finance tool,  
                            helping people worldwide achieve financial freedom and stability.
                        </p>
                    </div>
                </div>
            </div>
        </section>

        <!-- Team Section -->
        <section class="team-section bg-light">
            <div class="container text-center">
                <h2 class="mb-5">Meet the Team</h2>
                <div class="row">
                    <div class="col-md-4 mb-4">
                        <div class="card team-card shadow-sm p-3">
                            <img src="uploads/mira.jpg" alt="Team Member" width="120" class="mx-auto mb-3">
                            <h5>Mira</h5>
                            <p class="text-muted">Lead Developer</p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-4">
                        <div class="card team-card shadow-sm p-3">
                            <img src="uploads/rumi.jpg" alt="Team Member" width="120" class="mx-auto mb-3">
                            <h5>Rumi</h5>
                            <p class="text-muted">UI/UX Designer</p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-4">
                        <div class="card team-card shadow-sm p-3">
                            <img src="uploads/zora.jpg" alt="Team Member" width="120" class="mx-auto mb-3">
                            <h5>Zoey</h5>
                            <p class="text-muted">Project Manager</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    </div>
</div>

<script src="js/jquery.slim.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/feather.min.js"></script>
<script>
    feather.replace();
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
</script>
</body>
</html>
