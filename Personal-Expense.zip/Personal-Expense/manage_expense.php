<?php
include("session.php");


// Fetch user info including profile picture
$userQuery = mysqli_query($con, "SELECT firstname, lastname, email, profile_path FROM users WHERE user_id = '$userid'");
$userData = mysqli_fetch_assoc($userQuery);

$firstname = $userData['firstname'];
$lastname = $userData['lastname'];
$useremail = $userData['email'];
$profilePic = !empty($userData['profile_path']) ? 'uploads/' . $userData['profile_path'] : 'uploads/a.jpg';

// Get the selected sorting option from the form
$selectedSort = isset($_GET['sort']) ? $_GET['sort'] : 'none';
$searchCategory = isset($_GET['category']) ? trim($_GET['category']) : '';

// Build the SQL query with search and sorting
$sql = "SELECT * FROM expenses WHERE user_id = ?";
$params = [$userid];
$types = "i"; // integer type for user_id

if (!empty($searchCategory)) {
    $sql .= " AND expensecategory LIKE ?";
    $params[] = '%' . $searchCategory . '%';
    $types .= "s"; // string type for category
}

// Determine sorting
switch ($selectedSort) {
    case 'month':
        $sql .= " ORDER BY expensedate";
        break;
    case 'category':
        $sql .= " ORDER BY expensecategory";
        break;
    case 'none':
    default:
        $sql .= " ORDER BY expense_id DESC";
        break;
}

// Prepare statement
$stmt = $con->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$exp_fetched = $stmt->get_result();
?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Expense Manager - Manage Expenses</title>

<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<script src="js/feather.min.js"></script>

<style>

       .shadow-lg {
  box-shadow: 0 1rem 3rem rgba(0, 0, 0, 0.175) !important; /* default */
}

/* custom version */
.shadow-lg.custom-color {
  box-shadow: 0 1rem 3rem rgba(188, 18, 210, 0.5) !important; /* blue example */
}

      table.table tbody tr:nth-child(odd) {
    background-color: #f3c7efff; /* light gray */
  }
  table.table tbody tr:nth-child(even) {
    background-color: #ffe6f2; /* white */
  }

  /* Example: highlight on hover */
  table.table tbody tr:hover {
    background-color: #f397c3ff !important; /* light pink */
  }
.try {
  font-size: 28px;
  color: #333;
  padding: 15px 0px 5px 0px;
}
.user {
  text-align: center;
  padding: 20px 0;
}
.user img {
  margin-bottom: 10px;
}
</style>
</head>

<body>
<div class="d-flex" id="wrapper">
    <!-- Sidebar -->
    <div class="border-right" id="sidebar-wrapper" style="background-color: #ce9cdfff">
      <div class="user">
        <img class="img img-fluid rounded-circle" src="<?php echo $profilePic; ?>" width="120" alt="Profile Picture">
        <h5><?php echo htmlspecialchars($firstname . ' ' . $lastname); ?></h5>
        <p><?php echo htmlspecialchars($useremail); ?></p>
      </div>
      <div class="sidebar-heading" style="color: #333">Management</div>
      <div class="list-group list-group-flush">
        <a href="index.php" class="list-group-item list-group-item-action"><span data-feather="home"></span> Dashboard</a>
        <a href="add_expense.php" class="list-group-item list-group-item-action"><span data-feather="plus-square"></span> Add Expenses</a>
        <a href="manage_expense.php" class="list-group-item list-group-item-action sidebar-active"><span data-feather="dollar-sign"></span> Manage Expenses</a>
        <a href="expensereport.php" class="list-group-item list-group-item-action"><span data-feather="file-text"></span> Expense Report</a>
<a href="suggestion.php" class="list-group-item list-group-item-action"><span data-feather="message-square"></span> Suggestion Box</a>  
    </div>
      <div class="sidebar-heading" style="color: #333";>Settings </div>
      <div class="list-group list-group-flush">
        <a href="profile.php" class="list-group-item list-group-item-action"><span data-feather="user"></span> Profile</a>
        <a href="logout.php" class="list-group-item list-group-item-action"><span data-feather="power"></span> Logout</a>
      </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <div id="page-content-wrapper">
        <nav class="navbar navbar-expand-lg navbar-light border-bottom"style="background-color: #ce9cdfff" >
            <button class="toggler" type="button" id="menu-toggle" aria-expanded="false"  style="background-color: #ce9cdfff;margin-right: 5px;">
                <span data-feather="menu"></span>
            </button>
            <div class="col-md-11 text-center">
                <h3 class="try">Manage Expenses</h3>
            </div>
        </nav>
 <!-- for sort first -->
        <div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <form method="GET" action="">
                <div class="form-row align-items-end mt-3">
                    
                    <!-- Sort Dropdown -->
                    <div class="col-md-4">
                        <label for="sort">Sort By:</label>
                        <select class="form-control shadow-lg" id="sort" name="sort" onchange="this.form.submit()">
                            <option value="none" <?php if ($selectedSort === 'none') echo 'selected'; ?>>Recently Added</option>
                            <option value="month" <?php if ($selectedSort === 'month') echo 'selected'; ?>>Month</option>
                            <option value="category" <?php if ($selectedSort === 'category') echo 'selected'; ?>>Category</option>
                        </select>
                    </div>

                    <!-- Search Input -->
                    <div class="col-md-6">
                        <label for="category">Search by Category:</label>
                        <input type="text" class="form-control shadow-lg" id="category" name="category" 
                               placeholder="Enter category..." 
                               value="<?php echo isset($_GET['category']) ? htmlspecialchars($_GET['category']) : ''; ?>">
                    </div>

                    <!-- Search Button -->
                    <div class="col-md-2">
                        <button type="submit" class="btn  btn-block shadow-lg" style="background-color:#d48ee5ff">Search</button>
                    </div>

                </div>
            </form>

            <br>
            <table class="table table-hover table-bordered">
                <thead>
                    <tr class="text-center" style="background-color: #ce9cdfff;">
                        <th>No.</th>
                        <th>Date</th>
                        <th>Amount</th>
                        <th>Expense Category</th>
                        <th colspan="2">Action</th>
                    </tr>
                </thead>
      
                <tbody>
                <?php $count=1; while ($row = mysqli_fetch_array($exp_fetched)) { ?>
                    <tr>
                        <td class="text-center"><?php echo $count; ?></td>
                        <td class="text-center"><?php echo $row['expensedate']; ?></td>
                        <td class="text-center"><?php echo $row['expense']; ?></td>
                        <td class="text-center"><?php echo $row['expensecategory']; ?></td>
                        <td class="text-center">
                            <a href="add_expense.php?edit=<?php echo $row['expense_id']; ?>" class="btn btn-sm" style="border-radius:0%;border:2px solid;border-color: #c011ecff">Edit</a>
                        </td>
                        <td class="text-center">
                            <a href="add_expense.php?delete=<?php echo $row['expense_id']; ?>" class="btn btn-danger btn-sm" style="border-radius:0%;" onclick="return confirm('Are you sure you want to delete this expense?');">Delete</a>
                        </td>
                    </tr>
                <?php $count++; } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

    </div>
</div>

<script src="js/jquery.slim.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/Chart.min.js"></script>
<script>
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
    feather.replace();
</script>
</body>
</html>
