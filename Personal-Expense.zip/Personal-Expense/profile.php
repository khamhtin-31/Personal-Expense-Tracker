<?php
include("session.php");

// Fetch user info including profile picture
$userQuery = mysqli_query($con, "SELECT firstname, lastname, email, profile_path FROM users WHERE user_id = '$userid'");
$userData = mysqli_fetch_assoc($userQuery);

$firstname = $userData['firstname'];
$lastname = $userData['lastname'];
$useremail = $userData['email'];
$profilePic = !empty($userData['profile_path']) ? 'uploads/' . $userData['profile_path'] : 'uploads/a.jpg';

// Handle name update
if (isset($_POST['save'])) {
    $fname = mysqli_real_escape_string($con, $_POST['first_name']);
    $lname = mysqli_real_escape_string($con, $_POST['last_name']);

    $sql = "UPDATE users SET firstname = '$fname', lastname='$lname' WHERE user_id='$userid'";
    if (mysqli_query($con, $sql)) {
        // Update variables to reflect changes immediately
        $firstname = $fname;
        $lastname = $lname;
        // Optional: add a success message here if you want
    } else {
        echo "ERROR: Could not execute $sql. " . mysqli_error($con);
    }
    // No redirect here so we can show updated info immediately
}

// Handle profile picture upload
if (isset($_POST['but_upload'])) {
    if (isset($_FILES['file']) && $_FILES['file']['error'] == 0) {
        $name = $_FILES['file']['name'];
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($name);

        // File extension & validation
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        $extensions_arr = array("jpg", "jpeg", "png", "gif");

        if (in_array($imageFileType, $extensions_arr)) {
            // Move uploaded file
            if (move_uploaded_file($_FILES['file']['tmp_name'], $target_file)) {
                // Update DB
                $query = "UPDATE users SET profile_path = '$name' WHERE user_id='$userid'";
                mysqli_query($con, $query);

                // Update $profilePic variable to show new pic immediately
                $profilePic = $target_file;
            } else {
                echo "<div class='alert alert-danger'>Error uploading file.</div>";
            }
        } else {
            echo "<div class='alert alert-danger'>Invalid file type. Allowed: jpg, jpeg, png, gif.</div>";
        }
    } else {
        echo "<div class='alert alert-danger'>No file selected or error uploading.</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Expense Manager - Profile Update</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">

    <!-- Custom styles -->
    <link href="css/style.css" rel="stylesheet">

    <!-- Feather Icons -->
    <script src="js/feather.min.js"></script>

    <style>
        .try {
            font-size: 28px;
            color: #333;
            padding: 15px 65px 5px 0px;
        }
    </style>

</head>

<body>

    <div class="d-flex" id="wrapper">

        <!-- Sidebar -->
        <div class="border-right" id="sidebar-wrapper"  style="background-color: #ce9cdfff;">
            <div class="user text-center">
                <img class="img img-fluid rounded-circle" src="<?php echo $profilePic; ?>" width="120" alt="Profile Picture">
                <h5><?php echo htmlspecialchars($firstname . ' ' . $lastname); ?></h5>
                <p><?php echo htmlspecialchars($useremail); ?></p>
            </div>
            <div class="sidebar-heading" style="color:#333">Management</div>
            <div class="list-group list-group-flush">
                <a href="index.php" class="list-group-item list-group-item-action"><span data-feather="home"></span> Dashboard</a>
                <a href="add_expense.php" class="list-group-item list-group-item-action"><span data-feather="plus-square"></span> Add Expenses</a>
                <a href="manage_expense.php" class="list-group-item list-group-item-action"><span data-feather="dollar-sign"></span> Manage Expenses</a>
                <a href="expensereport.php" class="list-group-item list-group-item-action"><span data-feather="file-text"></span> Expense Report</a>
<a href="suggestion.php" class="list-group-item list-group-item-action"><span data-feather="message-square"></span> Suggestion Box</a>
            </div>
            <div class="sidebar-heading" style="color:#333">Settings</div>
            <div class="list-group list-group-flush">
                <a href="profile.php" class="list-group-item list-group-item-action sidebar-active"><span data-feather="user"></span> Profile</a>
                <a href="logout.php" class="list-group-item list-group-item-action"><span data-feather="power"></span> Logout</a>
            </div>
        </div>
        <!-- /#sidebar-wrapper -->

        <!-- Page Content -->
        <div id="page-content-wrapper">

            <nav class="navbar navbar-expand-lg navbar-light border-bottom"  style="background-color: #ce9cdfff;">

                <button class="toggler" type="button" id="menu-toggle" aria-expanded="false" style="background-color: #ce9cdfff;margin-right: 5px;">
                    <span data-feather="menu"></span>
                </button>
                <div class="col-md-12 text-center">
                    <h3 class="try">Update Profile</h3>
                </div>
            </nav>

            <div class="container-fluid">
                <div class="row justify-content-center">
                    <div class="col-md-6">

                        <!-- Profile Picture Upload Form -->
                        <form method="post" action="" enctype="multipart/form-data">
                            <div class="text-center mt-3">
                                <img src="<?php echo $profilePic; ?>" class="text-center img img-fluid rounded-circle avatar" width="120" alt="Profile Picture">
                            </div>

                            <div class="form-group mt-3">
                                <label for="file">Upload New Profile Picture</label>
                                <input type="file" name="file" id="file" class="file-upload form-control-file" accept="image/*" required>
                            </div>

                            <button class="btn  btn-block" name="but_upload" type="submit" style="border-radius:0%;background-color:#d48ee5ff">Upload Picture</button>
                        </form>

                        <hr>

                        <!-- Name Update Form -->
                        <form method="post" action="" id="registrationForm" autocomplete="off">
                            <div class="row">
                                <div class="col">
                                    <div class="form-group">
                                        <label for="first_name">First name</label>
                                        <input type="text" class="form-control" name="first_name" id="first_name" placeholder="First Name" value="<?php echo htmlspecialchars($firstname); ?>" required>
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="form-group">
                                        <label for="last_name">Last name</label>
                                        <input type="text" class="form-control" name="last_name" id="last_name" placeholder="Last Name" value="<?php echo htmlspecialchars($lastname); ?>" required>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="email">Email (cannot be changed)</label>
                                <input type="email" class="form-control" name="email" id="email" value="<?php echo htmlspecialchars($useremail); ?>" disabled>
                            </div>
                            <div class="form-group">
                                <button class="btn  btn-block" style="border-radius:0%;background-color:#d48ee5ff" name="save" type="submit">Save Changes</button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
        <!-- /#page-content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- Bootstrap JS and dependencies -->
    <script src="js/jquery.slim.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/Chart.min.js"></script>

    <!-- Menu Toggle Script -->
    <script>
        $("#menu-toggle").click(function(e) {
            e.preventDefault();
            $("#wrapper").toggleClass("toggled");
        });
    </script>

    <!-- Feather Icons replace -->
    <script>
        feather.replace()
    </script>

    <!-- Image preview on file select -->
    <script type="text/javascript">
        $(document).ready(function() {
            var readURL = function(input) {
                if (input.files && input.files[0]) {
                    var reader = new FileReader();

                    reader.onload = function(e) {
                        $('.avatar').attr('src', e.target.result);
                    }

                    reader.readAsDataURL(input.files[0]);
                }
            }

            $(".file-upload").on('change', function() {
                readURL(this);
            });
        });
    </script>

</body>

</html>
