<?php
include("session.php");

if(isset($_POST['category_name'])) {
    $category_name = trim($_POST['category_name']);
    if($category_name == '') exit('error');

    // Check duplicate
    $check = $con->prepare("SELECT * FROM expense_categories WHERE category_name=?");
    $check->bind_param("s",$category_name);
    $check->execute();
    $result = $check->get_result();
    if($result->num_rows > 0) {
        echo 'exists';
    } else {
        $stmt = $con->prepare("INSERT INTO expense_categories(category_name) VALUES(?)");
        $stmt->bind_param("s",$category_name);
        if($stmt->execute()) {
            // return new category id for table
            echo json_encode(['success'=>true,'id'=>$stmt->insert_id]);
        } else {
            echo 'error';
        }
        $stmt->close();
    }
    $check->close();
}
?>
